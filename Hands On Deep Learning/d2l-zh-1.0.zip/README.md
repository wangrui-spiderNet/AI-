# 动手学深度学习

[![Build Status](http://ci.diveintodeeplearning.org/job/zh/job/master/badge/icon)](http://ci.diveintodeeplearning.org/job/zh/job/master/)  

[[本书网址](https://zh.diveintodeeplearning.org/)]
 

## 英文版 *Dive into Deep Learning*

加州大学伯克利分校 2019 年春学期 *Introduction to Deep Learning* 课程教材。

开源地址：[https://github.com/diveintodeeplearning/d2l-en](https://github.com/diveintodeeplearning/d2l-en)


## 贡献

感谢[社区贡献者们](https://github.com/diveintodeeplearning/d2l-zh/graphs/contributors)为每一位读者改进这本开源书。

[[如何贡献](https://zh.diveintodeeplearning.org/chapter_appendix/how-to-contribute.html)] [[致谢](https://zh.diveintodeeplearning.org/chapter_introduction/preface.html#%E8%87%B4%E8%B0%A2)]  [[讨论或报告问题](https://discuss.gluon.ai)]  [[其他](INFO.md)]
